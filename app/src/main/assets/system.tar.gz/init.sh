#!/bin/sh
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export HOME=/root
export TMPDIR=/tmp

# إعداد DNS
echo "nameserver 8.8.8.8" > /etc/resolv.conf

# التثبيت السريع للحزم (Alpine apk سريع جداً)
if [ ! -f "/usr/bin/fluxbox" ]; then
    echo "📦 Installing Dependencies..."
    apk add --no-cache fluxbox x11vnc xvfb supervisor ttf-dejavu python3
fi

# فك ضغط فايرفوكس إذا لم يكن مفكوكاً
if [ ! -d "/opt/firefox" ]; then
    echo "🦊 Extracting Firefox..."
    # ملاحظة: سنحتاج tar يدعم xz، Alpine يمتلكه
    # نفترض أن الملف موجود في /opt
    cd /opt
    tar -xf firefox.tar.xz.tar
    # قد نحتاج فك الطبقة الثانية
    if [ -f "firefox-146.0.1.tar.xz" ]; then
        tar -xf firefox-146.0.1.tar.xz
        mv firefox firefox-folder
    fi
    # تنظيف
    rm *.tar*
fi

# تشغيل الشاشة الوهمية
echo "🖥️ Starting Xvfb..."
Xvfb :1 -screen 0 1280x720x24 &
sleep 2

# تشغيل مدير النوافذ
export DISPLAY=:1
fluxbox &

# تشغيل Firefox
echo "🔥 Starting Firefox..."
/opt/firefox/firefox --no-remote --display=:1 &

# إبقاء الحاوية حية
tail -f /dev/null
