#!/bin/sh
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export HOME=/root
export TMPDIR=/tmp

echo "nameserver 8.8.8.8" > /etc/resolv.conf

# تثبيت الحزم (Alpine سريع)
if [ ! -f "/usr/bin/fluxbox" ]; then
    apk add --no-cache fluxbox x11vnc xvfb supervisor ttf-dejavu python3 tar xz bash
fi

# فك noVNC
if [ ! -d "/opt/novnc" ]; then
    mkdir -p /opt/novnc
    tar -xf /opt/novnc.tar.gz -C /opt/novnc --strip-components=1
fi

# فك Firefox
if [ ! -d "/opt/firefox" ]; then
    cd /opt
    tar -xf firefox.tar.xz.tar
    # فك الطبقة الثانية إذا وجدت
    if [ -f "firefox-146.0.1.tar.xz" ]; then
        tar -xf firefox-146.0.1.tar.xz
        mv firefox firefox-folder
    fi
    rm *.tar*
fi

# تشغيل الخدمات
Xvfb :1 -screen 0 1280x720x24 &
sleep 2

/opt/novnc/utils/novnc_proxy --vnc localhost:5900 --listen 6080 &

export DISPLAY=:1
fluxbox &
x11vnc -display :1 -nopw -forever &

echo "🔥 Starting Firefox..."
/opt/firefox/firefox --no-remote --display=:1 &

tail -f /dev/null
